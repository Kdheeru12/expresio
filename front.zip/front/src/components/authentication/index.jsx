import AuthenticationRoute from "./AuthenticationRoute";
import Login from "./Login";
import Register from "./Register";

export { AuthenticationRoute, Login, Register };
